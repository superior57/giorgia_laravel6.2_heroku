@extends('admin.layouts.app')
@section('content')


<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            vessel
        </div>
    </div>
</div>



@endsection