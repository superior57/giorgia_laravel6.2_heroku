<!-- <footer class="ftco-footer ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Giorgia</h2>
              <ul class="ftco-footer-social list-unstyled mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          
          
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Company</h2>
              <ul class="list-unstyled">
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Home</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Vessel</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Experience</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Crew</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Enquire</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Contact</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">the Isle of Man, UK</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+2 392 3929 210</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope pr-4"></span><span class="text">info@yourdomain.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
	
            <p>
              Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made with <i class="icon-heart color-danger" aria-hidden="true"></i> by Colorlib
            </p>
          </div>
        </div>
      </div>
    </footer> -->












    <!-- Footer Section Start -->
		<footer class="full-row bg-secondery text-white footer-3 py-80" id="footer">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-sm-6">
						<div class="footer-widget get-in-touch icon-primary">
							<h4 class="widget-title down-line-left text-white">Get In Touch</h4>
							<ul>
								<li><i class="fas fa-map-marker-alt"></i>the Isle of Man, United Kingdom</li>
								<li><a href="mailto:helpdesk@info.com"><i class="fas fa-envelope"></i>info@Giorgia.com</a></li>
								<li><a href="callto:+1-000-991-8830"><i class="fas fa-phone"></i>+1-000-000-0000</a></li>
							</ul>
							<a href="#" class="btn btn-primary-bg">Book Now</a> </div>
					</div>
					<div class="col-lg-3 col-sm-6">
						<div class="footer-widget quick-link">
							<h4 class="widget-title down-line-left text-white">Company</h4>
							<ul>
								<li><a href="#">- Home</a></li>
								<li><a href="#">- Vessel</a></li>
								<li><a href="#">- Experience</a></li>
								<li><a href="#">- Crew</a></li>
								<li><a href="#">- Enquire</a></li>
								<li><a href="#">- Contact</a></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-3  col-sm-6">
						<div class="footer-widget instagram">
							<h4 class="widget-title down-line-left text-white">Instagram</h4>
							<ul>
								<li><a href="#"><img src="img/squire/6.jpg" alt="Image not found !"></a></li>
								<li><a href="#"><img src="img/squire/7.jpg" alt="Image not found !"></a></li>
								<li><a href="#"><img src="img/squire/8.jpg" alt="Image not found !"></a></li>
								<li><a href="#"><img src="img/squire/9.jpg" alt="Image not found !"></a></li>
								<li><a href="#"><img src="img/squire/10.jpg" alt="Image not found !"></a></li>
								<li><a href="#"><img src="img/squire/11.jpg" alt="Image not found !"></a></li>
								<li><a href="#"><img src="img/squire/6.jpg" alt="Image not found !"></a></li>
								<li><a href="#"><img src="img/squire/7.jpg" alt="Image not found !"></a></li>
								<li><a href="#"><img src="img/squire/8.jpg" alt="Image not found !"></a></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6">
						<div class="footer-widget newsletter">
							<h4 class="widget-title down-line-left text-white">Newslatter</h4>
							<p>Feugiat tempus. Non aliquet moles tie vulputate. Elit ipsum sit pharetra. Nascetur vulputate nam. Neque clas interdum.</p>
							<form action="#" method="post">
								<div class="form-group">
									<input class="form-control" type="text" name="mail" placeholder="Your Email">
								</div>
								<div class="form-group">
									<input class="btn btn-primary-bg" type="submit" value="Sign Up Now">
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="m-auto d-table">
							<ul class="social-media mt-5">
								<li><a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://twitter.com/"><i class="fab fa-twitter"></i></a></li>
								<li><a href="https://www.linkedin.com/"><i class="fab fa-linkedin-in"></i></a></li>
								<li><a href="https://plus.google.com/"><i class="fab fa-google-plus-g"></i></a></li>
								<li><a href="https://www.pinterest.com/"><i class="fab fa-pinterest-p"></i></a></li>
								<li><a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- Footer Section End --> 